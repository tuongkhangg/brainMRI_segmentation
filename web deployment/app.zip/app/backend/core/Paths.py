
file_path = [
    './app/backend/model/OkapiBM25/src/weight of Dataset/avgdl.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/dl.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/dltable.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/file2terms.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/files.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/idf.pkl',
    './app/backend/model/OkapiBM25/src/weight of Dataset/invertedIndex.pkl']

path_model = "./app/backend/model/CV/weight/weight.h5"