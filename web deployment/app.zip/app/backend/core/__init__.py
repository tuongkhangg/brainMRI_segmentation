from fastapi.templating import Jinja2Templates

TEMPLATE = Jinja2Templates("app/backend/jinja/templates")

